# Enter your API keys for the https://api.data.gov/ed/collegescorecard/v1/schools.json?api_key=

api_key = "pk.eyJ1Ijoic2Fob2JpdGF5byIsImEiOiJja2FnMHk4b3QwMTN1MnJzMnVrNHhjYWo4In0.rXx1TpZ65qMxOandee2DxQ"


ServerName = "map-db.cqzrlm7geovg.us-east-2.rds.amazonaws.com"
UserName = "postgres"
Password = "mchalo2000"
port = "5432"
DataBase = "map_db"




# {
#  "cells": [
#   {
#    "cell_type": "code",
#    "execution_count": null,
#    "metadata": {},
#    "outputs": [],
#    "source": []
#   }
#  ],
#  "metadata": {
#   "kernelspec": {
#    "display_name": "Python 3",
#    "language": "python",
#    "name": "python3"
#   },
#   "language_info": {
#    "codemirror_mode": {
#     "name": "ipython",
#     "version": 3
#    },
#    "file_extension": ".py",
#    "mimetype": "text/x-python",
#    "name": "python",
#    "nbconvert_exporter": "python",
#    "pygments_lexer": "ipython3",
#    "version": "3.7.4"
#   }
#  },
#  "nbformat": 4,
#  "nbformat_minor": 2
# }
